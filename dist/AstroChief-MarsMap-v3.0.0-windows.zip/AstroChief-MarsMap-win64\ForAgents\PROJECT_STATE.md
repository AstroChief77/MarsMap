# AstroChief Project State — v3.0.0 Complete Rewrite

Bu belge, `ForAgents/` klasörü altındaki ortak yapay zekâ ajan iletişim dokümanıdır (`readme.md` kuralı gereğince oluşturulmuştur).

## 1. Yapılan Yeniden Yazım (From Scratch Architecture — v3.0.0)
Eski v2.4.0 sürümünde harita varsayılan olarak 3D başlıyordu, güvenli rota hesaplaması devre dışı bırakılmıştı, dış ağ (Google Fonts / Unsplash) çağrıları vardı ve sol alt "Uydular" paneli fotoğraf arka planlı kompakt yapıda değildi. v3.0.0 ile proje **`readme.md` kurallarının tamamına uyacak şekilde baştan yazıldı**:

- **Varsayılan 3D Başlangıç (`AppConfig.getFactoryDefaults`)**: `viewMode: "3d"` olarak başlar.
- **Merkez Tam Ekran Mars Haritası (`index.html`, `Map2DRenderer.js`, `Map3DRenderer.js`)**: Yıldızlı siyah uzay (`StarfieldRenderer.js`) üstünde `./data/tiles/` karo piramidinden gerçek NASA Mars Trek yüzey karolarını çizer.
- **Çevrimdışı `res/` Paketi (`css/fonts.css`, `res/fonts/`, `res/images/`)**:
  - `Public Sans Web` (`400, 600, 700, 800, 900`, latin + latin-ext `.woff2`) yerel `res/fonts/` içine indirildi.
  - Sol alt `Uydular` panelindeki her seçenek için Mars bölge fotoğrafları `res/images/` altına kaydedildi (`sat_2d_view.jpg`, `sat_3d_view.jpg`, `acid_rain_region.jpg`, `dust_storm_region.jpg`, `radiation_region.jpg`, `perseverance_supercam_sol2031.jpg`). Runtime'da internetten kütüphane/font çekilmez.
- **Sol Üst Ayarlar (`SettingsPanel.js`)**:
  - Açıldığında **1. seçenek `Factory Reset`**.
  - Fabrika standartları: Ölçek yaklaştıkça Progressive LOD render (yalnızca görünür ekran karoları), birimler (`Litre`, `km`/`m`, `Saat`) ve `Alfa (α) / Beta (β) / Gama (γ)` + `Foton Bombardımanı` alanları görünürdür.
- **Sol Alt "Uydular" Paneli (`SatellitesPanel.js`, `satellites_panel.css`)**:
  - Görünüm (`2D` / `3D`), Asit Yağmuru (+ `Hafif / Orta / Şiddetli` pH seçenekleri), Kum Fırtınası (+ `Hafif / Orta / Şiddetli` optik derinlik τ seçenekleri), α/β/γ Foton kuşağı ve karo katmanları **tamamı Uydular penceresinin içinde**, az ve öz yazılarla ve arka planlarında ilgili Mars bölge fotoğraflarıyla yer alır.
- **Güvenli Çift Rota ve Yol Yorumları (`RoutePlannerService.js`, `RouteGeometryHelper.js`, `RouteCanvasRenderer.js`)**:
  - **En Güvenli Kısa Yol (Mavi `#2563eb`)** ve **Güvenli Uzun Alternatif Yol (Soluk Mavi `#93c5fd`)** asit yağmuru, kum fırtınası/kasırga ve foton alanlarından kaçınarak hesaplanır.
  - Harita üstünde yol yorum satırları (`// Mavi Yol: ...`, `// Soluk Mavi: ...`) ve sağ üst panelde `Saat`, `km / m`, `O₂ Litre`, `Su Litre` metrikleri canlı güncellenir.
- **FPS < 10 Ayar Koruma Servisi (`FpsGuardService.js`)**:
  - Herhangi bir ayar değiştirildiğinde gerçek veya simüle FPS 10'un altına düşerse değişikliği iptal edip bir önceki duruma geri döner ve kullanıcıya kırmızı uyarı bandı gösterir.
- **OS Duyarlı Derleme ve Masaüstü Dağıtımı (`tools/build.py`, `build.sh`, `tools/build_tool.ps1`)**:
  - Çalıştığı işletim sistemini (Linux / Windows) otomatik algılar; Linux `.tar.gz` veya Windows paketini üretip Masaüstündeki `AstroChief-MarsMap` dizinine kopyalar.

## 2. Kural Uyum Özeti
| Kural | Durum | Uygulayan Modül / Kanıt |
|---|---|---|
| `readme.md` dokunulmazlığı | Korundu | `git diff readme.md` temiz |
| Değişiklik öncesi yedek (`backups/`) | Uygulandı | `snapshot_20261114_v2_4_before_rewrite`, `snapshot_20261114_v3_pre_build`, `snapshot_20261114_v3_pre_polish`, `snapshot_20261114_v3_pre_final_polish` |
| Her dosya < 800 satır & OOP | Uygulandı | Tüm modüller <= 495 satır; `tools/build.py` denetler |
| Alt satır/işlev özeti & loglama | Uygulandı | Her kaynak kod dosyası sonunda ve `logs/change_log.txt` |
| %60 Beyaz / %30 Siyah / %10 Kırmızı + Public Sans Web | Uygulandı | `css/variables.css`, `css/fonts.css` |
| İşletim sistemine göre derleme + Masaüstü | Uygulandı | `tools/build.py`, `build.sh`, `tools/build_tool.ps1` |
