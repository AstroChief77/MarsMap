/* @ts-self-types="./backend.d.ts" */

/**
 * JS tarafından doğrudan çağrılan ana Rust hesaplama fonksiyonu.
 * Harita dizisini (tek boyutlu dizi veya 2D), boyutları, başlangıç ve hedefi JS verir.
 * Çıktı olarak JSON formatında yolu ve toplam maliyeti döner.
 * @param {Int32Array | number[]} grid_flat
 * @param {number} width
 * @param {number} height
 * @param {number} start_x
 * @param {number} start_y
 * @param {number} goal_x
 * @param {number} goal_y
 * @returns {string}
 */
export function find_rover_path(grid_flat, width, height, start_x, start_y, goal_x, goal_y) {
    let deferred8_0;
    let deferred8_1;
    const val2 = Math.trunc(+width);
    const val3 = Math.trunc(+height);
    const val4 = Math.trunc(+start_x);
    const val5 = Math.trunc(+start_y);
    const val6 = Math.trunc(+goal_x);
    const val7 = Math.trunc(+goal_y);
    if (!grid_flat || !Number.isFinite(val2) || !Number.isFinite(val3) || val2 <= 0 || val3 <= 0 || val2 > 16384 || val3 > 16384 || val2 * val3 > grid_flat.length) {
        return JSON.stringify({ status: "no_path", message: "Gecersiz harita boyutu veya dizi uzunlugu." });
    }
    if (!Number.isFinite(val4) || !Number.isFinite(val5) || !Number.isFinite(val6) || !Number.isFinite(val7) || val4 < 0 || val5 < 0 || val6 < 0 || val7 < 0 || val4 >= val2 || val5 >= val3 || val6 >= val2 || val7 >= val3) {
        return JSON.stringify({ status: "no_path", message: "Baslangic veya hedef koordinati harita disinda." });
    }
    try {
        const ptr0 = passArray32ToWasm0(grid_flat, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.find_rover_path(ptr0, len0, val2, val3, val4, val5, val6, val7);
        deferred8_0 = ret[0];
        deferred8_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        if (deferred8_0 !== undefined) {
            wasm.__wbindgen_free(deferred8_0, deferred8_1, 1);
        }
    }
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            table.set(0, undefined);
            table.set(1024, undefined);
            table.set(1025, null);
            table.set(1026, true);
            table.set(1027, false);
        },
    };
    return {
        __proto__: null,
        "./backend_bg.js": import0,
    };
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function passArray32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getUint32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(bytes) {
    numBytesDecoded += bytes.length;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true });
        cachedTextDecoder.decode();
        numBytesDecoded = bytes.length;
    }
    return cachedTextDecoder.decode(bytes);
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedUint32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (!module.ok) {
            throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
        }

        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

let __wbg_init_promise;
async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;
    if (__wbg_init_promise === undefined) {
        __wbg_init_promise = __wbg_init_once(module_or_path);
        __wbg_init_promise.catch(() => { __wbg_init_promise = undefined; });
    }
    return __wbg_init_promise;
}

async function __wbg_init_once(module_or_path) {

    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('backend_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };

/* ==========================================================================
   DOSYA SATIR VE ISLEV ACIKLAMALARI (Satir Satir Ne Ise Yaradigi):
   --------------------------------------------------------------------------
   - Satir 1-35: find_rover_path; Rust WASM A* rota bulucu baglayici fonksiyonu.
   - Satir 36-107: WASM bellek, dizi kopyalama (passArray32ToWasm0) ve UTF-8 metin cozumleyici yardimcilari.
   - Satir 109-202: __wbg_load, initSync ve __wbg_init; WebAssembly modul yukleme ve baslatma arayuzu.
   ========================================================================== */
